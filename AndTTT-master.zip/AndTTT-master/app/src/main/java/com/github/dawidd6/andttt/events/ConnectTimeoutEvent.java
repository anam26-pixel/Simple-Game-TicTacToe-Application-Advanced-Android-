package com.github.dawidd6.andttt.events;

public class ConnectTimeoutEvent {
    public ConnectTimeoutEvent() {
    }
}
